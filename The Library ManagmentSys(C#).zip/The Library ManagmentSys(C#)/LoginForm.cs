﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class LoginForm : MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        int count = 0;

        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
            sqlCon.Open();

        }

        private void mbtnLogin_Click(object sender, EventArgs e)
        {
            string utype;
            try
            {
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "Select * from login_ta Where username='" + mtxtUsername.Text + "'and userpassword='" + mtxtPassword.Text + "'";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                count = Convert.ToInt32(dt.Rows.Count.ToString());

                if (dt.Rows.Count> 0)
                {
                    utype = dt.Rows[0][4].ToString().Trim();
                    if (utype == "A")
                    {
                        this.Hide();
                        AdminForm adminf = new AdminForm();
                        adminf.Show();
                    }

                    else if (utype=="S")
                    {
                        this.Hide();
                        StudentsPage studentsPage = new StudentsPage();
                        studentsPage.Show();

                    }

                    //MessageBox.Show("UserName Password does not match");
                }

                else
                {

                    MessageBox.Show("UserName Password does not match");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mbtnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
