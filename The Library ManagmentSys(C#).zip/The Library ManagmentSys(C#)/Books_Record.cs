﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Books_Record : MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Books_Record()
        {
            InitializeComponent();
        }

        private void Books_Record_Load(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();

            }
            sqlCon.Open();
            book_info();
        }

        public void book_info()
        {
            SqlCommand sqcom = sqlCon.CreateCommand();
            sqcom.CommandType = CommandType.Text;
            sqcom.CommandText = "select * from books";// where students_enroll_no='" + mbtnEnrollno.ToString() + "'";
            sqcom.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqcom);
            da.Fill(dt);
            dgvbookrecord1.DataSource = dt;

        }

        private void dgvbookrecord1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string i;
            try
            {



                i = dgvbookrecord1.SelectedCells[0].Value.ToString();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from issue_books where book_name='" + i.ToString() + "' and books_return_date=''";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvbookrecord2.DataSource = dt;

                MessageBox.Show(i.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtbookname_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {


                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_name like('%" + mtxtbookname.Text + "%')";// where students_enroll_no='" + mbtnEnrollno.ToString() + "'";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvbookrecord1.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvbookrecord2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string i;
            try
            {
                i = dgvbookrecord2.SelectedCells[6].Value.ToString();
                mtxtemail.Text = i.ToString();
            }
            catch (Exception ex)
            {

            }
        }

        private void mbtnsend_Click(object sender, EventArgs e)
        {

        }
        //catch(Exception ex)
        //    {

        //    }
    }
}
