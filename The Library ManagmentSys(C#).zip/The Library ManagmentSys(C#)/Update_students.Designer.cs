﻿namespace The_Library_ManagmentSys
{
    partial class Update_students
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.mbtnUpdate = new MetroFramework.Controls.MetroButton();
            this.dgvupdatestd = new System.Windows.Forms.DataGridView();
            this.mtxtStudentemail = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentcontact = new MetroFramework.Controls.MetroTextBox();
            this.mtxtxStudentsem = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentdept = new MetroFramework.Controls.MetroTextBox();
            this.mtxtstdname = new MetroFramework.Controls.MetroTextBox();
            this.mtxtstdenroll = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvupdatestd)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.mbtnUpdate);
            this.metroPanel1.Controls.Add(this.dgvupdatestd);
            this.metroPanel1.Controls.Add(this.mtxtStudentemail);
            this.metroPanel1.Controls.Add(this.mtxtStudentcontact);
            this.metroPanel1.Controls.Add(this.mtxtxStudentsem);
            this.metroPanel1.Controls.Add(this.mtxtStudentdept);
            this.metroPanel1.Controls.Add(this.mtxtstdname);
            this.metroPanel1.Controls.Add(this.mtxtstdenroll);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(14, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(735, 378);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.ForeColor = System.Drawing.Color.Black;
            this.metroLabel6.Location = new System.Drawing.Point(13, 241);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(115, 19);
            this.metroLabel6.TabIndex = 23;
            this.metroLabel6.Text = "Student Contact";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.BackColor = System.Drawing.Color.DarkSlateGray;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(13, 281);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(100, 19);
            this.metroLabel5.TabIndex = 22;
            this.metroLabel5.Text = "Student Email";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(11, 204);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(126, 19);
            this.metroLabel4.TabIndex = 21;
            this.metroLabel4.Text = "Student Semester";
            this.metroLabel4.Click += new System.EventHandler(this.metroLabel4_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(9, 165);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(144, 19);
            this.metroLabel3.TabIndex = 20;
            this.metroLabel3.Text = "Student Department";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(9, 125);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(126, 19);
            this.metroLabel7.TabIndex = 19;
            this.metroLabel7.Text = "Student Enroll No";
            this.metroLabel7.Click += new System.EventHandler(this.metroLabel7_Click);
            // 
            // mbtnUpdate
            // 
            this.mbtnUpdate.Location = new System.Drawing.Point(167, 330);
            this.mbtnUpdate.Name = "mbtnUpdate";
            this.mbtnUpdate.Size = new System.Drawing.Size(75, 23);
            this.mbtnUpdate.TabIndex = 18;
            this.mbtnUpdate.Text = "Update";
            this.mbtnUpdate.Click += new System.EventHandler(this.mbtnUpdate_Click);
            // 
            // dgvupdatestd
            // 
            this.dgvupdatestd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvupdatestd.Location = new System.Drawing.Point(361, 80);
            this.dgvupdatestd.Name = "dgvupdatestd";
            this.dgvupdatestd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvupdatestd.Size = new System.Drawing.Size(341, 255);
            this.dgvupdatestd.TabIndex = 17;
            this.dgvupdatestd.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvupdatestd_CellClick);
            this.dgvupdatestd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvupdatestd_CellContentClick);
            // 
            // mtxtStudentemail
            // 
            this.mtxtStudentemail.Location = new System.Drawing.Point(241, 277);
            this.mtxtStudentemail.Name = "mtxtStudentemail";
            this.mtxtStudentemail.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentemail.TabIndex = 16;
            // 
            // mtxtStudentcontact
            // 
            this.mtxtStudentcontact.Location = new System.Drawing.Point(241, 237);
            this.mtxtStudentcontact.Name = "mtxtStudentcontact";
            this.mtxtStudentcontact.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentcontact.TabIndex = 15;
            // 
            // mtxtxStudentsem
            // 
            this.mtxtxStudentsem.Location = new System.Drawing.Point(241, 200);
            this.mtxtxStudentsem.Name = "mtxtxStudentsem";
            this.mtxtxStudentsem.Size = new System.Drawing.Size(75, 23);
            this.mtxtxStudentsem.TabIndex = 14;
            // 
            // mtxtStudentdept
            // 
            this.mtxtStudentdept.Location = new System.Drawing.Point(241, 165);
            this.mtxtStudentdept.Name = "mtxtStudentdept";
            this.mtxtStudentdept.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentdept.TabIndex = 12;
            // 
            // mtxtstdname
            // 
            this.mtxtstdname.Location = new System.Drawing.Point(241, 80);
            this.mtxtstdname.Name = "mtxtstdname";
            this.mtxtstdname.Size = new System.Drawing.Size(75, 23);
            this.mtxtstdname.TabIndex = 11;
            // 
            // mtxtstdenroll
            // 
            this.mtxtstdenroll.Location = new System.Drawing.Point(241, 125);
            this.mtxtstdenroll.Name = "mtxtstdenroll";
            this.mtxtstdenroll.Size = new System.Drawing.Size(75, 23);
            this.mtxtstdenroll.TabIndex = 10;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(9, 80);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(104, 19);
            this.metroLabel2.TabIndex = 4;
            this.metroLabel2.Text = "Student Name";
            // 
            // Update_students
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Update_students";
            this.Text = "Update_students";
            this.Load += new System.EventHandler(this.Update_students_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvupdatestd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnUpdate;
        private System.Windows.Forms.DataGridView dgvupdatestd;
        private MetroFramework.Controls.MetroTextBox mtxtStudentemail;
        private MetroFramework.Controls.MetroTextBox mtxtStudentcontact;
        private MetroFramework.Controls.MetroTextBox mtxtxStudentsem;
        private MetroFramework.Controls.MetroTextBox mtxtStudentdept;
        private MetroFramework.Controls.MetroTextBox mtxtstdname;
        private MetroFramework.Controls.MetroTextBox mtxtstdenroll;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel7;
    }
}