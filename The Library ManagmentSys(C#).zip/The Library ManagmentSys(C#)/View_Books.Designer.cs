﻿namespace The_Library_ManagmentSys
{
    partial class View_Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mbtnSearch = new MetroFramework.Controls.MetroButton();
            this.dgvViewbooks = new System.Windows.Forms.DataGridView();
            this.mtxtBooktype = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookauthor = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookid = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookname = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.mlblBooksname = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewbooks)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.mbtnSearch);
            this.metroPanel1.Controls.Add(this.dgvViewbooks);
            this.metroPanel1.Controls.Add(this.mtxtBooktype);
            this.metroPanel1.Controls.Add(this.mtxtBookauthor);
            this.metroPanel1.Controls.Add(this.mtxtBookid);
            this.metroPanel1.Controls.Add(this.mtxtBookname);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.mlblBooksname);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(707, 337);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // mbtnSearch
            // 
            this.mbtnSearch.Location = new System.Drawing.Point(188, 276);
            this.mbtnSearch.Name = "mbtnSearch";
            this.mbtnSearch.Size = new System.Drawing.Size(75, 23);
            this.mbtnSearch.TabIndex = 11;
            this.mbtnSearch.Text = "Search";
            this.mbtnSearch.Click += new System.EventHandler(this.mbtnSearch_Click);
            // 
            // dgvViewbooks
            // 
            this.dgvViewbooks.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgvViewbooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewbooks.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dgvViewbooks.Location = new System.Drawing.Point(407, 3);
            this.dgvViewbooks.Name = "dgvViewbooks";
            this.dgvViewbooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvViewbooks.Size = new System.Drawing.Size(297, 331);
            this.dgvViewbooks.TabIndex = 10;
            // 
            // mtxtBooktype
            // 
            this.mtxtBooktype.Location = new System.Drawing.Point(207, 228);
            this.mtxtBooktype.Name = "mtxtBooktype";
            this.mtxtBooktype.Size = new System.Drawing.Size(75, 23);
            this.mtxtBooktype.TabIndex = 9;
            this.mtxtBooktype.Click += new System.EventHandler(this.mtxtBookcate_Click);
            this.mtxtBooktype.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtBooktype_KeyUp);
            // 
            // mtxtBookauthor
            // 
            this.mtxtBookauthor.Location = new System.Drawing.Point(207, 167);
            this.mtxtBookauthor.Name = "mtxtBookauthor";
            this.mtxtBookauthor.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookauthor.TabIndex = 8;
            this.mtxtBookauthor.Click += new System.EventHandler(this.mtxtBookauthor_Click);
            this.mtxtBookauthor.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtBookauthor_KeyUp);
            // 
            // mtxtBookid
            // 
            this.mtxtBookid.Location = new System.Drawing.Point(207, 115);
            this.mtxtBookid.Name = "mtxtBookid";
            this.mtxtBookid.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookid.TabIndex = 7;
            this.mtxtBookid.Click += new System.EventHandler(this.mtxtBookid_Click);
            this.mtxtBookid.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtBookid_KeyUp);
            // 
            // mtxtBookname
            // 
            this.mtxtBookname.Location = new System.Drawing.Point(207, 66);
            this.mtxtBookname.Name = "mtxtBookname";
            this.mtxtBookname.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookname.TabIndex = 6;
            this.mtxtBookname.Click += new System.EventHandler(this.mtxtBooksname_Click);
            this.mtxtBookname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtBookname_KeyUp);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(37, 228);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(70, 19);
            this.metroLabel4.TabIndex = 5;
            this.metroLabel4.Text = "Book Type";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(37, 167);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(83, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Book Author";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(41, 115);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(54, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Book Id";
            // 
            // mlblBooksname
            // 
            this.mlblBooksname.AutoSize = true;
            this.mlblBooksname.Location = new System.Drawing.Point(37, 66);
            this.mlblBooksname.Name = "mlblBooksname";
            this.mlblBooksname.Size = new System.Drawing.Size(79, 19);
            this.mlblBooksname.TabIndex = 2;
            this.mlblBooksname.Text = "Book Name";
            // 
            // View_Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "View_Books";
            this.Text = "View_Books";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.View_Books_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewbooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.DataGridView dgvViewbooks;
        private MetroFramework.Controls.MetroTextBox mtxtBooktype;
        private MetroFramework.Controls.MetroTextBox mtxtBookauthor;
        private MetroFramework.Controls.MetroTextBox mtxtBookid;
        private MetroFramework.Controls.MetroTextBox mtxtBookname;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel mlblBooksname;
        private MetroFramework.Controls.MetroButton mbtnSearch;
    }
}