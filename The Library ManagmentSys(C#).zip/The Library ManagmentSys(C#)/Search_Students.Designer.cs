﻿namespace The_Library_ManagmentSys
{
    partial class Search_Students
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mtxtstudentdep = new MetroFramework.Controls.MetroTextBox();
            this.mtxtEnrollno = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.mbtnStdsearch = new MetroFramework.Controls.MetroButton();
            this.dgvstdsearch = new System.Windows.Forms.DataGridView();
            this.mtxtStudentid = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentsName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvstdsearch)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.mtxtstudentdep);
            this.metroPanel1.Controls.Add(this.mtxtEnrollno);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.mbtnStdsearch);
            this.metroPanel1.Controls.Add(this.dgvstdsearch);
            this.metroPanel1.Controls.Add(this.mtxtStudentid);
            this.metroPanel1.Controls.Add(this.mtxtStudentsName);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(764, 364);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // mtxtstudentdep
            // 
            this.mtxtstudentdep.Location = new System.Drawing.Point(185, 215);
            this.mtxtstudentdep.Name = "mtxtstudentdep";
            this.mtxtstudentdep.Size = new System.Drawing.Size(75, 23);
            this.mtxtstudentdep.TabIndex = 11;
            this.mtxtstudentdep.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtstudentdep_KeyUp);
            // 
            // mtxtEnrollno
            // 
            this.mtxtEnrollno.Location = new System.Drawing.Point(185, 158);
            this.mtxtEnrollno.Name = "mtxtEnrollno";
            this.mtxtEnrollno.Size = new System.Drawing.Size(75, 23);
            this.mtxtEnrollno.TabIndex = 10;
            this.mtxtEnrollno.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtEnrollno_KeyUp);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(31, 158);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(128, 19);
            this.metroLabel4.TabIndex = 9;
            this.metroLabel4.Text = "Student Enroll NO";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(31, 215);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(148, 19);
            this.metroLabel3.TabIndex = 8;
            this.metroLabel3.Text = "Student Department ";
            // 
            // mbtnStdsearch
            // 
            this.mbtnStdsearch.Location = new System.Drawing.Point(193, 298);
            this.mbtnStdsearch.Name = "mbtnStdsearch";
            this.mbtnStdsearch.Size = new System.Drawing.Size(75, 23);
            this.mbtnStdsearch.TabIndex = 7;
            this.mbtnStdsearch.Text = "Search";
            this.mbtnStdsearch.Click += new System.EventHandler(this.mbtnStdsearch_Click);
            // 
            // dgvstdsearch
            // 
            this.dgvstdsearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvstdsearch.Location = new System.Drawing.Point(386, 3);
            this.dgvstdsearch.Name = "dgvstdsearch";
            this.dgvstdsearch.Size = new System.Drawing.Size(352, 341);
            this.dgvstdsearch.TabIndex = 6;
            // 
            // mtxtStudentid
            // 
            this.mtxtStudentid.Location = new System.Drawing.Point(185, 45);
            this.mtxtStudentid.Name = "mtxtStudentid";
            this.mtxtStudentid.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentid.TabIndex = 5;
            this.mtxtStudentid.Click += new System.EventHandler(this.mtxtStudentid_Click);
            this.mtxtStudentid.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtStudentid_KeyUp);
            // 
            // mtxtStudentsName
            // 
            this.mtxtStudentsName.Location = new System.Drawing.Point(185, 99);
            this.mtxtStudentsName.Name = "mtxtStudentsName";
            this.mtxtStudentsName.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentsName.TabIndex = 4;
            this.mtxtStudentsName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtStudentsName_KeyUp);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(31, 45);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(77, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Student Id";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(31, 99);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(104, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Student Name";
            // 
            // Search_Students
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Search_Students";
            this.Text = "Search_Students";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Search_Students_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvstdsearch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.DataGridView dgvstdsearch;
        private MetroFramework.Controls.MetroTextBox mtxtStudentid;
        private MetroFramework.Controls.MetroTextBox mtxtStudentsName;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton mbtnStdsearch;
        private MetroFramework.Controls.MetroTextBox mtxtstudentdep;
        private MetroFramework.Controls.MetroTextBox mtxtEnrollno;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
    }
}