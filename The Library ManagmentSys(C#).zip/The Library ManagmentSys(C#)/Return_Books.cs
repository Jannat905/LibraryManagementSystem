﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Return_Books : MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Return_Books()
        {
            InitializeComponent();
        }

        private void Return_Books_Load(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();

            }
            sqlCon.Open();
        }

        private void metroPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mbtnStdsearchr_Click(object sender, EventArgs e)
        {
            mpdgv.Visible = true;
            fill_grid(mbtnEnrollno.Text);
        }
        public void fill_grid(string mbtnEnrollno)
        {
            SqlCommand sqcom = sqlCon.CreateCommand();
            sqcom.CommandType = CommandType.Text;
            sqcom.CommandText = "select * from issue_books where students_enroll_no='" + mbtnEnrollno.ToString() + "'";
            sqcom.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqcom);
            da.Fill(dt);
            dgvreturn.DataSource = dt;
        }

        private void mbtnEnrollno_Click(object sender, EventArgs e)
        {

        }

        private void lblbookmane_Click(object sender, EventArgs e)
        {

        }

        private void dgvreturn_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            mpshow.Visible = true;

            int i;
       
            i = Convert.ToInt32(dgvreturn.SelectedCells[0].Value.ToString());
            SqlCommand sqcom = sqlCon.CreateCommand();
            sqcom.CommandType = CommandType.Text;
            sqcom.CommandText = " select * from issue_books where issue_id=" + i+"";
            sqcom.ExecuteNonQuery();
            DataTable dt= new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(sqcom);
            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)

            {
                lblbookmane.Text = dr["book_name"].ToString();
                lblissuedate.Text = Convert.ToString(dr["books_issue_date"].ToString());

            }
        }

        private void mbtnreturn_Click(object sender, EventArgs e)
        {
            int i;

            i = Convert.ToInt32(dgvreturn.SelectedCells[0].Value.ToString());
            SqlCommand sqcom = sqlCon.CreateCommand();
            sqcom.CommandType = CommandType.Text;
            sqcom.CommandText = " update issue_books set books_return_date='"+ dtpreturndate.Value.ToString()+ "'where issue_id=" + i + "";
            sqcom.ExecuteNonQuery();


            SqlCommand sqcom2 = sqlCon.CreateCommand();
            sqcom2.CommandType = CommandType.Text;
            sqcom2.CommandText = "update books set available_quantity= available_quantity+1 where book_name='"+lblbookmane.Text+"'";
            sqcom2.ExecuteNonQuery();
            MessageBox.Show("Books Return");
           // mpdgv.Visible = false;
            mpshow.Visible = true;
            fill_grid(mbtnEnrollno.Text);
        }
    }
}
