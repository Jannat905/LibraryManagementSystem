﻿namespace The_Library_ManagmentSys
{
    partial class StudentsPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mbtnBack = new MetroFramework.Controls.MetroButton();
            this.mbtnReturnedbook = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.mbtnBorrowbooks = new MetroFramework.Controls.MetroButton();
            this.mbtnSearchbook = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.mbtnBack);
            this.metroPanel1.Controls.Add(this.mbtnReturnedbook);
            this.metroPanel1.Controls.Add(this.metroButton3);
            this.metroPanel1.Controls.Add(this.mbtnBorrowbooks);
            this.metroPanel1.Controls.Add(this.mbtnSearchbook);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(1, 82);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(797, 365);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mbtnBack
            // 
            this.mbtnBack.Location = new System.Drawing.Point(352, 291);
            this.mbtnBack.Name = "mbtnBack";
            this.mbtnBack.Size = new System.Drawing.Size(75, 23);
            this.mbtnBack.TabIndex = 6;
            this.mbtnBack.Text = "Back";
            this.mbtnBack.Click += new System.EventHandler(this.mbtnBack_Click);
            // 
            // mbtnReturnedbook
            // 
            this.mbtnReturnedbook.Location = new System.Drawing.Point(302, 151);
            this.mbtnReturnedbook.Name = "mbtnReturnedbook";
            this.mbtnReturnedbook.Size = new System.Drawing.Size(167, 23);
            this.mbtnReturnedbook.TabIndex = 5;
            this.mbtnReturnedbook.Text = "Return Book";
            this.mbtnReturnedbook.Click += new System.EventHandler(this.mbtnReturnedbook_Click);
            // 
            // metroButton3
            // 
            this.metroButton3.Location = new System.Drawing.Point(302, 209);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(167, 23);
            this.metroButton3.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroButton3.TabIndex = 4;
            this.metroButton3.Text = "metroButton3";
            // 
            // mbtnBorrowbooks
            // 
            this.mbtnBorrowbooks.Location = new System.Drawing.Point(302, 105);
            this.mbtnBorrowbooks.Name = "mbtnBorrowbooks";
            this.mbtnBorrowbooks.Size = new System.Drawing.Size(167, 23);
            this.mbtnBorrowbooks.TabIndex = 3;
            this.mbtnBorrowbooks.Text = "Borrow Books";
            this.mbtnBorrowbooks.Click += new System.EventHandler(this.mbtnBorrowbooks_Click);
            // 
            // mbtnSearchbook
            // 
            this.mbtnSearchbook.Location = new System.Drawing.Point(302, 54);
            this.mbtnSearchbook.Name = "mbtnSearchbook";
            this.mbtnSearchbook.Size = new System.Drawing.Size(167, 23);
            this.mbtnSearchbook.TabIndex = 2;
            this.mbtnSearchbook.Text = "Search Books";
            this.mbtnSearchbook.Click += new System.EventHandler(this.mbtnSearchbook_Click);
            // 
            // StudentsPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "StudentsPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Student Form";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.StudentsPage_Load);
            this.metroPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnReturnedbook;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton mbtnBorrowbooks;
        private MetroFramework.Controls.MetroButton mbtnSearchbook;
        private MetroFramework.Controls.MetroButton mbtnBack;
    }
}