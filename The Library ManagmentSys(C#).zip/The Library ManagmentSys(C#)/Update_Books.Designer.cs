﻿namespace The_Library_ManagmentSys
{
    partial class Update_Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.mtxtBooktype = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookquantity = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookprice = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookpublication = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookauthor = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookname = new MetroFramework.Controls.MetroTextBox();
            this.dgvUpdatebooks = new System.Windows.Forms.DataGridView();
            this.dtpupdatebookdate = new System.Windows.Forms.DateTimePicker();
            this.mbtnupdatebook = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpdatebooks)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.mbtnupdatebook);
            this.metroPanel1.Controls.Add(this.dtpupdatebookdate);
            this.metroPanel1.Controls.Add(this.dgvUpdatebooks);
            this.metroPanel1.Controls.Add(this.mtxtBooktype);
            this.metroPanel1.Controls.Add(this.mtxtBookquantity);
            this.metroPanel1.Controls.Add(this.mtxtBookprice);
            this.metroPanel1.Controls.Add(this.mtxtBookpublication);
            this.metroPanel1.Controls.Add(this.mtxtBookauthor);
            this.metroPanel1.Controls.Add(this.mtxtBookname);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(8, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(779, 455);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(15, 71);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(0, 0);
            this.metroLabel1.TabIndex = 2;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(15, 297);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(80, 19);
            this.metroLabel7.TabIndex = 15;
            this.metroLabel7.Text = "Book Type";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.Location = new System.Drawing.Point(15, 260);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(105, 19);
            this.metroLabel6.TabIndex = 14;
            this.metroLabel6.Text = "Book Quantity";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(15, 219);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(82, 19);
            this.metroLabel5.TabIndex = 13;
            this.metroLabel5.Text = "Book Price";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(15, 180);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(40, 19);
            this.metroLabel4.TabIndex = 12;
            this.metroLabel4.Text = "Date";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(15, 142);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(123, 19);
            this.metroLabel3.TabIndex = 11;
            this.metroLabel3.Text = "Book Publication";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(15, 108);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(138, 19);
            this.metroLabel2.TabIndex = 10;
            this.metroLabel2.Text = "Book Author Name";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel8.Location = new System.Drawing.Point(17, 70);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(88, 19);
            this.metroLabel8.TabIndex = 9;
            this.metroLabel8.Text = "Book Name";
            // 
            // mtxtBooktype
            // 
            this.mtxtBooktype.Location = new System.Drawing.Point(240, 294);
            this.mtxtBooktype.Name = "mtxtBooktype";
            this.mtxtBooktype.Size = new System.Drawing.Size(75, 23);
            this.mtxtBooktype.TabIndex = 23;
            // 
            // mtxtBookquantity
            // 
            this.mtxtBookquantity.Location = new System.Drawing.Point(240, 262);
            this.mtxtBookquantity.Name = "mtxtBookquantity";
            this.mtxtBookquantity.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookquantity.TabIndex = 22;
            // 
            // mtxtBookprice
            // 
            this.mtxtBookprice.Location = new System.Drawing.Point(240, 221);
            this.mtxtBookprice.Name = "mtxtBookprice";
            this.mtxtBookprice.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookprice.TabIndex = 21;
            // 
            // mtxtBookpublication
            // 
            this.mtxtBookpublication.Location = new System.Drawing.Point(240, 144);
            this.mtxtBookpublication.Name = "mtxtBookpublication";
            this.mtxtBookpublication.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookpublication.TabIndex = 20;
            // 
            // mtxtBookauthor
            // 
            this.mtxtBookauthor.Location = new System.Drawing.Point(240, 110);
            this.mtxtBookauthor.Name = "mtxtBookauthor";
            this.mtxtBookauthor.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookauthor.TabIndex = 19;
            // 
            // mtxtBookname
            // 
            this.mtxtBookname.Location = new System.Drawing.Point(240, 68);
            this.mtxtBookname.Name = "mtxtBookname";
            this.mtxtBookname.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookname.TabIndex = 18;
            // 
            // dgvUpdatebooks
            // 
            this.dgvUpdatebooks.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvUpdatebooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUpdatebooks.Location = new System.Drawing.Point(340, 66);
            this.dgvUpdatebooks.Name = "dgvUpdatebooks";
            this.dgvUpdatebooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUpdatebooks.Size = new System.Drawing.Size(429, 330);
            this.dgvUpdatebooks.TabIndex = 25;
            this.dgvUpdatebooks.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // dtpupdatebookdate
            // 
            this.dtpupdatebookdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpupdatebookdate.Location = new System.Drawing.Point(240, 180);
            this.dtpupdatebookdate.Name = "dtpupdatebookdate";
            this.dtpupdatebookdate.Size = new System.Drawing.Size(78, 20);
            this.dtpupdatebookdate.TabIndex = 26;
            // 
            // mbtnupdatebook
            // 
            this.mbtnupdatebook.Location = new System.Drawing.Point(162, 373);
            this.mbtnupdatebook.Name = "mbtnupdatebook";
            this.mbtnupdatebook.Size = new System.Drawing.Size(75, 23);
            this.mbtnupdatebook.TabIndex = 27;
            this.mbtnupdatebook.Text = "Update";
            this.mbtnupdatebook.Click += new System.EventHandler(this.mbtnupdatebook_Click);
            // 
            // Update_Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 534);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Update_Books";
            this.Text = "Update_Books";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Update_Books_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUpdatebooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.DataGridView dgvUpdatebooks;
        private MetroFramework.Controls.MetroTextBox mtxtBooktype;
        private MetroFramework.Controls.MetroTextBox mtxtBookquantity;
        private MetroFramework.Controls.MetroTextBox mtxtBookprice;
        private MetroFramework.Controls.MetroTextBox mtxtBookpublication;
        private MetroFramework.Controls.MetroTextBox mtxtBookauthor;
        private MetroFramework.Controls.MetroTextBox mtxtBookname;
        private System.Windows.Forms.DateTimePicker dtpupdatebookdate;
        private MetroFramework.Controls.MetroButton mbtnupdatebook;
    }
}