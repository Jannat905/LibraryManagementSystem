﻿namespace The_Library_ManagmentSys
{
    partial class Return_Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mbtnStdsearchr = new MetroFramework.Controls.MetroButton();
            this.mbtnEnrollno = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.lblbookmane = new MetroFramework.Controls.MetroLabel();
            this.lblissuedate = new MetroFramework.Controls.MetroLabel();
            this.lblreturndate = new MetroFramework.Controls.MetroLabel();
            this.mpdgv = new MetroFramework.Controls.MetroPanel();
            this.mpshow = new MetroFramework.Controls.MetroPanel();
            this.mbtnreturn = new MetroFramework.Controls.MetroButton();
            this.dtpreturndate = new System.Windows.Forms.DateTimePicker();
            this.dgvreturn = new System.Windows.Forms.DataGridView();
            this.metroPanel1.SuspendLayout();
            this.mpdgv.SuspendLayout();
            this.mpshow.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvreturn)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.mpshow);
            this.metroPanel1.Controls.Add(this.mpdgv);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.Controls.Add(this.mbtnEnrollno);
            this.metroPanel1.Controls.Add(this.mbtnStdsearchr);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 80);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(754, 347);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mbtnStdsearchr
            // 
            this.mbtnStdsearchr.Location = new System.Drawing.Point(170, 58);
            this.mbtnStdsearchr.Name = "mbtnStdsearchr";
            this.mbtnStdsearchr.Size = new System.Drawing.Size(93, 23);
            this.mbtnStdsearchr.TabIndex = 8;
            this.mbtnStdsearchr.Text = "Search Book";
            this.mbtnStdsearchr.Click += new System.EventHandler(this.mbtnStdsearchr_Click);
            // 
            // mbtnEnrollno
            // 
            this.mbtnEnrollno.Location = new System.Drawing.Point(23, 58);
            this.mbtnEnrollno.Name = "mbtnEnrollno";
            this.mbtnEnrollno.Size = new System.Drawing.Size(122, 23);
            this.mbtnEnrollno.TabIndex = 9;
            this.mbtnEnrollno.Click += new System.EventHandler(this.mbtnEnrollno_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(78, 14);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(107, 19);
            this.metroLabel1.TabIndex = 10;
            this.metroLabel1.Text = "Enrollment NO";
            // 
            // lblbookmane
            // 
            this.lblbookmane.AutoSize = true;
            this.lblbookmane.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblbookmane.Location = new System.Drawing.Point(24, 20);
            this.lblbookmane.Name = "lblbookmane";
            this.lblbookmane.Size = new System.Drawing.Size(88, 19);
            this.lblbookmane.TabIndex = 12;
            this.lblbookmane.Text = "Book Name";
            this.lblbookmane.Click += new System.EventHandler(this.lblbookmane_Click);
            // 
            // lblissuedate
            // 
            this.lblissuedate.AutoSize = true;
            this.lblissuedate.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblissuedate.Location = new System.Drawing.Point(204, 19);
            this.lblissuedate.Name = "lblissuedate";
            this.lblissuedate.Size = new System.Drawing.Size(76, 19);
            this.lblissuedate.TabIndex = 13;
            this.lblissuedate.Text = "Issue Date";
            // 
            // lblreturndate
            // 
            this.lblreturndate.AutoSize = true;
            this.lblreturndate.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.lblreturndate.Location = new System.Drawing.Point(24, 68);
            this.lblreturndate.Name = "lblreturndate";
            this.lblreturndate.Size = new System.Drawing.Size(132, 19);
            this.lblreturndate.TabIndex = 14;
            this.lblreturndate.Text = "Select Return Date";
            // 
            // mpdgv
            // 
            this.mpdgv.Controls.Add(this.dgvreturn);
            this.mpdgv.HorizontalScrollbarBarColor = true;
            this.mpdgv.HorizontalScrollbarHighlightOnWheel = false;
            this.mpdgv.HorizontalScrollbarSize = 10;
            this.mpdgv.Location = new System.Drawing.Point(304, 14);
            this.mpdgv.Name = "mpdgv";
            this.mpdgv.Size = new System.Drawing.Size(438, 166);
            this.mpdgv.TabIndex = 15;
            this.mpdgv.VerticalScrollbarBarColor = true;
            this.mpdgv.VerticalScrollbarHighlightOnWheel = false;
            this.mpdgv.VerticalScrollbarSize = 10;
            this.mpdgv.Visible = false;
            // 
            // mpshow
            // 
            this.mpshow.Controls.Add(this.dtpreturndate);
            this.mpshow.Controls.Add(this.mbtnreturn);
            this.mpshow.Controls.Add(this.lblreturndate);
            this.mpshow.Controls.Add(this.lblissuedate);
            this.mpshow.Controls.Add(this.lblbookmane);
            this.mpshow.HorizontalScrollbarBarColor = true;
            this.mpshow.HorizontalScrollbarHighlightOnWheel = false;
            this.mpshow.HorizontalScrollbarSize = 10;
            this.mpshow.Location = new System.Drawing.Point(78, 219);
            this.mpshow.Name = "mpshow";
            this.mpshow.Size = new System.Drawing.Size(579, 112);
            this.mpshow.TabIndex = 16;
            this.mpshow.VerticalScrollbarBarColor = true;
            this.mpshow.VerticalScrollbarHighlightOnWheel = false;
            this.mpshow.VerticalScrollbarSize = 10;
            this.mpshow.Visible = false;
            this.mpshow.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel3_Paint);
            // 
            // mbtnreturn
            // 
            this.mbtnreturn.Location = new System.Drawing.Point(282, 68);
            this.mbtnreturn.Name = "mbtnreturn";
            this.mbtnreturn.Size = new System.Drawing.Size(75, 23);
            this.mbtnreturn.TabIndex = 15;
            this.mbtnreturn.Text = "Return";
            this.mbtnreturn.Click += new System.EventHandler(this.mbtnreturn_Click);
            // 
            // dtpreturndate
            // 
            this.dtpreturndate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpreturndate.Location = new System.Drawing.Point(397, 18);
            this.dtpreturndate.Name = "dtpreturndate";
            this.dtpreturndate.Size = new System.Drawing.Size(78, 20);
            this.dtpreturndate.TabIndex = 16;
            // 
            // dgvreturn
            // 
            this.dgvreturn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvreturn.Location = new System.Drawing.Point(3, 3);
            this.dgvreturn.Name = "dgvreturn";
            this.dgvreturn.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvreturn.Size = new System.Drawing.Size(432, 160);
            this.dgvreturn.TabIndex = 2;
            this.dgvreturn.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvreturn_CellClick);
            // 
            // Return_Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Return_Books";
            this.Text = "Return_Books";
            this.Load += new System.EventHandler(this.Return_Books_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.mpdgv.ResumeLayout(false);
            this.mpshow.ResumeLayout(false);
            this.mpshow.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvreturn)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnStdsearchr;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox mbtnEnrollno;
        private MetroFramework.Controls.MetroPanel mpshow;
        private System.Windows.Forms.DateTimePicker dtpreturndate;
        private MetroFramework.Controls.MetroButton mbtnreturn;
        private MetroFramework.Controls.MetroLabel lblreturndate;
        private MetroFramework.Controls.MetroLabel lblissuedate;
        private MetroFramework.Controls.MetroLabel lblbookmane;
        private MetroFramework.Controls.MetroPanel mpdgv;
        private System.Windows.Forms.DataGridView dgvreturn;
    }
}