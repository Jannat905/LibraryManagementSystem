﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Update_students :MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Update_students()
        {
            InitializeComponent();
        }

        private void Update_students_Load(object sender, EventArgs e)
        {
       
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvupdatestd.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            disp_students();

        }
        private void dgvupdatestd_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = Convert.ToInt32(dgvupdatestd.SelectedCells[0].Value.ToString());
            //MessageBox.Show(i.ToString());

            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where id="+i+"";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    mtxtstdname.Text = dr["students_name"].ToString();
                    mtxtstdenroll.Text = dr["students_enroll_no"].ToString();
                    mtxtStudentdept.Text = dr["students_dept"].ToString();
                    mtxtxStudentsem.Text = dr["students_sem"].ToString();
                    mtxtStudentcontact.Text = dr["students_contact"].ToString();
                    mtxtStudentemail.Text = dr["students_email"].ToString();


                }
                dgvupdatestd.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void metroLabel7_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void mbtnUpdate_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(dgvupdatestd.SelectedCells[0].Value.ToString());
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "update students_info  set students_name='"+ mtxtstdname.Text+"',students_enroll_no='" + mtxtstdenroll.Text +"',students_dept='"+ mtxtStudentdept.Text+"',students_sem='"+ mtxtxStudentsem.Text+"',students_contact='"+ mtxtStudentcontact.Text+"',students_email='"+ mtxtStudentemail.Text +"'where id=" +i+"";
                sqcom.ExecuteNonQuery();
                sqlCon.Close();
                disp_students();

                mtxtstdname.Text = "";
                mtxtstdenroll.Text = "";
                mtxtStudentdept.Text = "";
                // mtxtBookdate.Text = "";
                mtxtxStudentsem.Text = "";
                mtxtStudentcontact.Text = "";
                mtxtStudentemail.Text = "";

                MessageBox.Show("Record Update");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void disp_students()
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvupdatestd.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dgvupdatestd_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
