﻿namespace The_Library_ManagmentSys
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mbtnExit = new MetroFramework.Controls.MetroButton();
            this.mbtnLogin = new MetroFramework.Controls.MetroButton();
            this.mtxtPassword = new MetroFramework.Controls.MetroTextBox();
            this.mtxtUsername = new MetroFramework.Controls.MetroTextBox();
            this.mlblPassword = new MetroFramework.Controls.MetroLabel();
            this.mlblUserName = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.mbtnExit);
            this.metroPanel1.Controls.Add(this.mbtnLogin);
            this.metroPanel1.Controls.Add(this.mtxtPassword);
            this.metroPanel1.Controls.Add(this.mtxtUsername);
            this.metroPanel1.Controls.Add(this.mlblPassword);
            this.metroPanel1.Controls.Add(this.mlblUserName);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(-2, 63);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(799, 384);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // mbtnExit
            // 
            this.mbtnExit.Location = new System.Drawing.Point(488, 240);
            this.mbtnExit.Name = "mbtnExit";
            this.mbtnExit.Size = new System.Drawing.Size(75, 23);
            this.mbtnExit.TabIndex = 8;
            this.mbtnExit.Text = "Exit";
            this.mbtnExit.Click += new System.EventHandler(this.mbtnExit_Click);
            // 
            // mbtnLogin
            // 
            this.mbtnLogin.Location = new System.Drawing.Point(268, 240);
            this.mbtnLogin.Name = "mbtnLogin";
            this.mbtnLogin.Size = new System.Drawing.Size(75, 23);
            this.mbtnLogin.TabIndex = 7;
            this.mbtnLogin.Text = "Login";
            this.mbtnLogin.Click += new System.EventHandler(this.mbtnLogin_Click);
            // 
            // mtxtPassword
            // 
            this.mtxtPassword.Location = new System.Drawing.Point(317, 156);
            this.mtxtPassword.Name = "mtxtPassword";
            this.mtxtPassword.PasswordChar = '*';
            this.mtxtPassword.Size = new System.Drawing.Size(75, 23);
            this.mtxtPassword.TabIndex = 6;
            // 
            // mtxtUsername
            // 
            this.mtxtUsername.Location = new System.Drawing.Point(317, 82);
            this.mtxtUsername.Name = "mtxtUsername";
            this.mtxtUsername.Size = new System.Drawing.Size(75, 23);
            this.mtxtUsername.TabIndex = 5;
            // 
            // mlblPassword
            // 
            this.mlblPassword.AutoSize = true;
            this.mlblPassword.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.mlblPassword.Location = new System.Drawing.Point(116, 160);
            this.mlblPassword.Name = "mlblPassword";
            this.mlblPassword.Size = new System.Drawing.Size(73, 19);
            this.mlblPassword.TabIndex = 4;
            this.mlblPassword.Text = "Password";
            // 
            // mlblUserName
            // 
            this.mlblUserName.AutoSize = true;
            this.mlblUserName.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.mlblUserName.Location = new System.Drawing.Point(116, 87);
            this.mlblUserName.Name = "mlblUserName";
            this.mlblUserName.Size = new System.Drawing.Size(79, 19);
            this.mlblUserName.TabIndex = 3;
            this.mlblUserName.Text = "UserName";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(317, 27);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(81, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "LoginForm";
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "LoginForm";
            this.Text = "Login ";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnExit;
        private MetroFramework.Controls.MetroButton mbtnLogin;
        private MetroFramework.Controls.MetroTextBox mtxtPassword;
        private MetroFramework.Controls.MetroTextBox mtxtUsername;
        private MetroFramework.Controls.MetroLabel mlblPassword;
        private MetroFramework.Controls.MetroLabel mlblUserName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
    }
}

