﻿namespace The_Library_ManagmentSys
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mbtnbookrecord = new MetroFramework.Controls.MetroButton();
            this.mbtnreturnbooks = new MetroFramework.Controls.MetroButton();
            this.mbtnissuebooks = new MetroFramework.Controls.MetroButton();
            this.mbtnDeletestd = new MetroFramework.Controls.MetroButton();
            this.mbtnUpdatestd = new MetroFramework.Controls.MetroButton();
            this.mbtnSearchstd = new MetroFramework.Controls.MetroButton();
            this.mbtnAddstd = new MetroFramework.Controls.MetroButton();
            this.mbtnDeletebook = new MetroFramework.Controls.MetroButton();
            this.mbtnUpdatebook = new MetroFramework.Controls.MetroButton();
            this.mbtnViewbooks = new MetroFramework.Controls.MetroButton();
            this.mbtnAddbooks = new MetroFramework.Controls.MetroButton();
            this.mbtnAllbook = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.AutoSize = true;
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.mbtnAllbook);
            this.metroPanel1.Controls.Add(this.mbtnbookrecord);
            this.metroPanel1.Controls.Add(this.mbtnreturnbooks);
            this.metroPanel1.Controls.Add(this.mbtnissuebooks);
            this.metroPanel1.Controls.Add(this.mbtnDeletestd);
            this.metroPanel1.Controls.Add(this.mbtnUpdatestd);
            this.metroPanel1.Controls.Add(this.mbtnSearchstd);
            this.metroPanel1.Controls.Add(this.mbtnAddstd);
            this.metroPanel1.Controls.Add(this.mbtnDeletebook);
            this.metroPanel1.Controls.Add(this.mbtnUpdatebook);
            this.metroPanel1.Controls.Add(this.mbtnViewbooks);
            this.metroPanel1.Controls.Add(this.mbtnAddbooks);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 87);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(754, 340);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mbtnbookrecord
            // 
            this.mbtnbookrecord.Location = new System.Drawing.Point(126, 301);
            this.mbtnbookrecord.Name = "mbtnbookrecord";
            this.mbtnbookrecord.Size = new System.Drawing.Size(99, 23);
            this.mbtnbookrecord.TabIndex = 13;
            this.mbtnbookrecord.Text = "Books Record";
            this.mbtnbookrecord.Click += new System.EventHandler(this.mbtnbookrecord_Click);
            // 
            // mbtnreturnbooks
            // 
            this.mbtnreturnbooks.Location = new System.Drawing.Point(126, 261);
            this.mbtnreturnbooks.Name = "mbtnreturnbooks";
            this.mbtnreturnbooks.Size = new System.Drawing.Size(99, 23);
            this.mbtnreturnbooks.TabIndex = 12;
            this.mbtnreturnbooks.TabStop = false;
            this.mbtnreturnbooks.Text = "Return Books";
            this.mbtnreturnbooks.Click += new System.EventHandler(this.mbtnreturnbooks_Click);
            // 
            // mbtnissuebooks
            // 
            this.mbtnissuebooks.Location = new System.Drawing.Point(126, 210);
            this.mbtnissuebooks.Name = "mbtnissuebooks";
            this.mbtnissuebooks.Size = new System.Drawing.Size(99, 23);
            this.mbtnissuebooks.TabIndex = 11;
            this.mbtnissuebooks.Text = "Issue Books";
            this.mbtnissuebooks.Click += new System.EventHandler(this.mbtnissuebooks_Click);
            // 
            // mbtnDeletestd
            // 
            this.mbtnDeletestd.Location = new System.Drawing.Point(447, 240);
            this.mbtnDeletestd.Name = "mbtnDeletestd";
            this.mbtnDeletestd.Size = new System.Drawing.Size(75, 23);
            this.mbtnDeletestd.TabIndex = 9;
            this.mbtnDeletestd.Text = "Delete Student";
            this.mbtnDeletestd.Click += new System.EventHandler(this.mbtnDeletestd_Click);
            // 
            // mbtnUpdatestd
            // 
            this.mbtnUpdatestd.Location = new System.Drawing.Point(447, 174);
            this.mbtnUpdatestd.Name = "mbtnUpdatestd";
            this.mbtnUpdatestd.Size = new System.Drawing.Size(75, 23);
            this.mbtnUpdatestd.TabIndex = 8;
            this.mbtnUpdatestd.Text = "Update Student";
            this.mbtnUpdatestd.Click += new System.EventHandler(this.mbtnUpdatestd_Click);
            // 
            // mbtnSearchstd
            // 
            this.mbtnSearchstd.Location = new System.Drawing.Point(447, 103);
            this.mbtnSearchstd.Name = "mbtnSearchstd";
            this.mbtnSearchstd.Size = new System.Drawing.Size(75, 23);
            this.mbtnSearchstd.TabIndex = 7;
            this.mbtnSearchstd.Text = "Search Student";
            this.mbtnSearchstd.Click += new System.EventHandler(this.mtxtSearchstd_Click);
            // 
            // mbtnAddstd
            // 
            this.mbtnAddstd.Location = new System.Drawing.Point(447, 32);
            this.mbtnAddstd.Name = "mbtnAddstd";
            this.mbtnAddstd.Size = new System.Drawing.Size(75, 23);
            this.mbtnAddstd.TabIndex = 6;
            this.mbtnAddstd.Text = "Add Students";
            this.mbtnAddstd.Click += new System.EventHandler(this.mbtnAddstd_Click);
            // 
            // mbtnDeletebook
            // 
            this.mbtnDeletebook.Location = new System.Drawing.Point(126, 160);
            this.mbtnDeletebook.Name = "mbtnDeletebook";
            this.mbtnDeletebook.Size = new System.Drawing.Size(99, 23);
            this.mbtnDeletebook.TabIndex = 5;
            this.mbtnDeletebook.Text = "Delete Books";
            // 
            // mbtnUpdatebook
            // 
            this.mbtnUpdatebook.Location = new System.Drawing.Point(126, 113);
            this.mbtnUpdatebook.Name = "mbtnUpdatebook";
            this.mbtnUpdatebook.Size = new System.Drawing.Size(99, 23);
            this.mbtnUpdatebook.TabIndex = 4;
            this.mbtnUpdatebook.Text = "Update Books";
            this.mbtnUpdatebook.Click += new System.EventHandler(this.mbtnUpdatebook_Click);
            // 
            // mbtnViewbooks
            // 
            this.mbtnViewbooks.Location = new System.Drawing.Point(126, 71);
            this.mbtnViewbooks.Name = "mbtnViewbooks";
            this.mbtnViewbooks.Size = new System.Drawing.Size(99, 23);
            this.mbtnViewbooks.TabIndex = 3;
            this.mbtnViewbooks.Text = "View Books";
            this.mbtnViewbooks.Click += new System.EventHandler(this.mbtnViewbooks_Click);
            // 
            // mbtnAddbooks
            // 
            this.mbtnAddbooks.Location = new System.Drawing.Point(126, 21);
            this.mbtnAddbooks.Name = "mbtnAddbooks";
            this.mbtnAddbooks.Size = new System.Drawing.Size(99, 23);
            this.mbtnAddbooks.TabIndex = 2;
            this.mbtnAddbooks.Text = "Add Books";
            this.mbtnAddbooks.Click += new System.EventHandler(this.mbtnAddbooks_Click);
            // 
            // mbtnAllbook
            // 
            this.mbtnAllbook.Location = new System.Drawing.Point(311, 31);
            this.mbtnAllbook.Name = "mbtnAllbook";
            this.mbtnAllbook.Size = new System.Drawing.Size(75, 23);
            this.mbtnAllbook.TabIndex = 14;
            this.mbtnAllbook.Text = "All Books";
            this.mbtnAllbook.Click += new System.EventHandler(this.mbtnAllbook_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.metroPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnDeletestd;
        private MetroFramework.Controls.MetroButton mbtnUpdatestd;
        private MetroFramework.Controls.MetroButton mbtnSearchstd;
        private MetroFramework.Controls.MetroButton mbtnAddstd;
        private MetroFramework.Controls.MetroButton mbtnDeletebook;
        private MetroFramework.Controls.MetroButton mbtnUpdatebook;
        private MetroFramework.Controls.MetroButton mbtnViewbooks;
        private MetroFramework.Controls.MetroButton mbtnAddbooks;
        private MetroFramework.Controls.MetroButton mbtnissuebooks;
        private MetroFramework.Controls.MetroButton mbtnreturnbooks;
        private MetroFramework.Controls.MetroButton mbtnbookrecord;
        private MetroFramework.Controls.MetroButton mbtnAllbook;
    }
}