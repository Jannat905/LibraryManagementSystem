﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class View_Books : MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public View_Books()
        {
            InitializeComponent();
        }

        private void View_Books_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvViewbooks.DataSource = dt;
                sqlCon.Close();

        
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void mtxtBookauthor_Click(object sender, EventArgs e)
        {

        }

        private void mtxtBookcate_Click(object sender, EventArgs e)
        {

        }

        private void mtxtBookid_Click(object sender, EventArgs e)
        {

        }

        private void mtxtBooksname_Click(object sender, EventArgs e)
        {

        }

        private void mbtnSearch_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_name like('%"+ mtxtBookname.Text + "%') and book_id like('%" + mtxtBookid.Text + "%') and book_author_name like('%" + mtxtBookauthor.Text + "%') and book_type like('%" + mtxtBooktype.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dgvViewbooks.DataSource = dt;
                sqlCon.Close();

                if(i==0)
                {
                    MessageBox.Show("No Books Found");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void mtxtBookname_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_name like('%" + mtxtBookname.Text + "%') and book_id like('%" + mtxtBookid.Text + "%') and book_author_name like('%" + mtxtBookauthor.Text + "%') and book_type like('%" + mtxtBooktype.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvViewbooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtBookid_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_name like('%" + mtxtBookname.Text + "%') and book_id like('%" + mtxtBookid.Text + "%') and book_author_name like('%" + mtxtBookauthor.Text + "%') and book_type like('%" + mtxtBooktype.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvViewbooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtBookauthor_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_name like('%" + mtxtBookname.Text + "%') and book_id like('%" + mtxtBookid.Text + "%') and book_author_name like('%" + mtxtBookauthor.Text + "%') and book_type like('%" + mtxtBooktype.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvViewbooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtBooktype_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_name like('%" + mtxtBookname.Text + "%') and book_id like('%" + mtxtBookid.Text + "%') and book_author_name like('%" + mtxtBookauthor.Text + "%') and book_type like('%" + mtxtBooktype.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvViewbooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
