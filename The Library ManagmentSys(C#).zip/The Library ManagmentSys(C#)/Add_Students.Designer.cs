﻿namespace The_Library_ManagmentSys
{
    partial class Add_Students
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.mtxtStudentname = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStuentenroll = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentdept = new MetroFramework.Controls.MetroTextBox();
            this.mtxtxStudentsem = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentcontact = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentemail = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.dgvAddstudent = new System.Windows.Forms.DataGridView();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddstudent)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.metroPanel1.Controls.Add(this.dgvAddstudent);
            this.metroPanel1.Controls.Add(this.metroButton1);
            this.metroPanel1.Controls.Add(this.mtxtStudentemail);
            this.metroPanel1.Controls.Add(this.mtxtStudentcontact);
            this.metroPanel1.Controls.Add(this.mtxtxStudentsem);
            this.metroPanel1.Controls.Add(this.mtxtStudentdept);
            this.metroPanel1.Controls.Add(this.mtxtStuentenroll);
            this.metroPanel1.Controls.Add(this.mtxtStudentname);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.ForeColor = System.Drawing.Color.White;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(39, 76);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(822, 436);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroLabel1
            // 
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(37, 40);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(126, 23);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Student Name";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(37, 103);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(126, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Student Enroll No";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(37, 162);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(144, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Student Department";
            this.metroLabel3.Click += new System.EventHandler(this.metroLabel3_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(38, 217);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(126, 19);
            this.metroLabel4.TabIndex = 5;
            this.metroLabel4.Text = "Student Semester";
            this.metroLabel4.Click += new System.EventHandler(this.metroLabel4_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.BackColor = System.Drawing.Color.DarkSlateGray;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(38, 336);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(100, 19);
            this.metroLabel5.TabIndex = 6;
            this.metroLabel5.Text = "Student Email";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.ForeColor = System.Drawing.Color.Black;
            this.metroLabel6.Location = new System.Drawing.Point(37, 272);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(115, 19);
            this.metroLabel6.TabIndex = 7;
            this.metroLabel6.Text = "Student Contact";
            // 
            // mtxtStudentname
            // 
            this.mtxtStudentname.Location = new System.Drawing.Point(247, 40);
            this.mtxtStudentname.Name = "mtxtStudentname";
            this.mtxtStudentname.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentname.TabIndex = 8;
            this.mtxtStudentname.Click += new System.EventHandler(this.metroTextBox1_Click);
            // 
            // mtxtStuentenroll
            // 
            this.mtxtStuentenroll.Location = new System.Drawing.Point(247, 103);
            this.mtxtStuentenroll.Name = "mtxtStuentenroll";
            this.mtxtStuentenroll.Size = new System.Drawing.Size(75, 23);
            this.mtxtStuentenroll.TabIndex = 9;
            // 
            // mtxtStudentdept
            // 
            this.mtxtStudentdept.Location = new System.Drawing.Point(247, 162);
            this.mtxtStudentdept.Name = "mtxtStudentdept";
            this.mtxtStudentdept.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentdept.TabIndex = 10;
            // 
            // mtxtxStudentsem
            // 
            this.mtxtxStudentsem.Location = new System.Drawing.Point(247, 217);
            this.mtxtxStudentsem.Name = "mtxtxStudentsem";
            this.mtxtxStudentsem.Size = new System.Drawing.Size(75, 23);
            this.mtxtxStudentsem.TabIndex = 11;
            // 
            // mtxtStudentcontact
            // 
            this.mtxtStudentcontact.Location = new System.Drawing.Point(247, 272);
            this.mtxtStudentcontact.Name = "mtxtStudentcontact";
            this.mtxtStudentcontact.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentcontact.TabIndex = 12;
            // 
            // mtxtStudentemail
            // 
            this.mtxtStudentemail.Location = new System.Drawing.Point(247, 336);
            this.mtxtStudentemail.Name = "mtxtStudentemail";
            this.mtxtStudentemail.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentemail.TabIndex = 13;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(173, 400);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 14;
            this.metroButton1.Text = "Save";
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // dgvAddstudent
            // 
            this.dgvAddstudent.BackgroundColor = System.Drawing.Color.SeaShell;
            this.dgvAddstudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAddstudent.Location = new System.Drawing.Point(360, 40);
            this.dgvAddstudent.Name = "dgvAddstudent";
            this.dgvAddstudent.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAddstudent.Size = new System.Drawing.Size(438, 383);
            this.dgvAddstudent.TabIndex = 15;
            this.dgvAddstudent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAddstudent_CellContentClick);
            // 
            // Add_Students
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 562);
            this.Controls.Add(this.metroPanel1);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Name = "Add_Students";
            this.Text = "Add_Students";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Add_Students_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAddstudent)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox mtxtStudentemail;
        private MetroFramework.Controls.MetroTextBox mtxtStudentcontact;
        private MetroFramework.Controls.MetroTextBox mtxtxStudentsem;
        private MetroFramework.Controls.MetroTextBox mtxtStudentdept;
        private MetroFramework.Controls.MetroTextBox mtxtStuentenroll;
        private MetroFramework.Controls.MetroTextBox mtxtStudentname;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.DataGridView dgvAddstudent;
    }
}