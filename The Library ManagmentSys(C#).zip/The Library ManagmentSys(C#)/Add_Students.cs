﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Add_Students :MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Add_Students()
        {
            InitializeComponent();
        }

        private void Add_Students_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvAddstudent.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            disp_students();



        }

        private void metroLabel3_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel4_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "insert into Students_info(students_name,students_enroll_no,students_dept,students_sem,students_contact,students_email) values ('" + mtxtStudentname.Text + "','" + mtxtStuentenroll.Text + "','" + mtxtStudentdept.Text + "','" + mtxtxStudentsem.Text + "','" + mtxtStudentcontact.Text + "','" + mtxtStudentemail.Text + "')";
                 //sqcom.CommandText = "insert into students_info values(''" + mtxtStudentname.Text + "','" +.Text + "','" + mtxtBookpublication.Text + "','" + mtxtBookdate.Text + "'," + mtxtBookprice.Text + "," + mtxtBookquantity.Text + ",'" + mtxtBooktype.Text + "')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                sqlCon.Close();
                disp_students();

                mtxtStudentname.Text = "";
                mtxtStuentenroll.Text = "";
                mtxtStudentdept.Text = "";
                mtxtxStudentsem.Text = "";
                mtxtStudentcontact.Text = "";
                mtxtStudentemail.Text = "";
                //.Text = "";

                MessageBox.Show("Student Added");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void disp_students()
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvAddstudent.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void dgvAddstudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
