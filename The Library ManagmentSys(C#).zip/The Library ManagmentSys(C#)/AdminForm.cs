﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Library_ManagmentSys
{
    public partial class AdminForm :MetroFramework.Forms.MetroForm
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

        }

        private void mbtnAddbooks_Click(object sender, EventArgs e)
        {
            Add_Books add_Books = new Add_Books();
            add_Books.Show();
        }

        private void mbtnViewbooks_Click(object sender, EventArgs e)
        {
            View_Books view_Books = new View_Books();
            view_Books.Show();

        }

        private void mbtnUpdatebook_Click(object sender, EventArgs e)
        {
            Update_Books update_Books = new Update_Books();
            update_Books.Show();
        }

        private void mbtnAddstd_Click(object sender, EventArgs e)
        {
            Add_Students add_Students  = new Add_Students();
            add_Students.Show();
        }

        private void mtxtSearchstd_Click(object sender, EventArgs e)
        {
            Search_Students search_Students = new Search_Students();
            search_Students.Show();
            

        }

        private void mbtnUpdatestd_Click(object sender, EventArgs e)
        {
            Update_students update_Students = new Update_students();
            update_Students.Show();

        }

        private void mbtnDeletestd_Click(object sender, EventArgs e)
        {
            Delete_Students delete_Students = new Delete_Students();
            delete_Students.Show();
        }

        private void mbtnissuebooks_Click(object sender, EventArgs e)
        {
            Issue_Books issue_Books = new Issue_Books();
            issue_Books.Show();
        }

        private void mbtnreturnbooks_Click(object sender, EventArgs e)
        {
            Return_Books return_Books = new Return_Books();
            return_Books.Show();

        }

        private void mbtnbookrecord_Click(object sender, EventArgs e)
        {
            Books_Record books_Record = new Books_Record();
            books_Record.Show();
                
        }

        private void mbtnAllbook_Click(object sender, EventArgs e)
        {
            All_Book all_Book = new All_Book();
            all_Book.Show();
                
        }
    }
}
