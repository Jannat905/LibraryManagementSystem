﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Library_ManagmentSys
{
    public partial class Delete_Students : MetroFramework.Forms.MetroForm
    {
        public Delete_Students()
        {
            InitializeComponent();
        }

        private void Delete_Students_Load(object sender, EventArgs e)
        {

        }
    }
}
