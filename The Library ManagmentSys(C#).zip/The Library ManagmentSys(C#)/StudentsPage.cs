﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Library_ManagmentSys
{
    public partial class StudentsPage : MetroFramework.Forms.MetroForm
    {
        public StudentsPage()
        {
            InitializeComponent();
        }

        private void StudentsPage_Load(object sender, EventArgs e)
        {

        }

        private void mbtnSearchbook_Click(object sender, EventArgs e)
        {
            View_Books view_Books = new View_Books();
            view_Books.Show();


        }

        private void mbtnReturnedbook_Click(object sender, EventArgs e)
        {
            Return_Books return_Books = new Return_Books();
            return_Books.Show();
        }

        private void mbtnBorrowbooks_Click(object sender, EventArgs e)
        {
            Issue_Books issue_Books = new Issue_Books();
            issue_Books.Show();
        }

        private void mbtnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
