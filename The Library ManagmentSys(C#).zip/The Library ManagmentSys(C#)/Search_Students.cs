﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Search_Students :MetroFramework.Forms.MetroForm
    {

        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Search_Students()
        {
            InitializeComponent();
        }

        private void Search_Students_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvstdsearch.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void mtxtStudentid_Click(object sender, EventArgs e)
        {

        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void mbtnStdsearch_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where  id like('%" + mtxtStudentid.Text + "%') and students_name like('%" + mtxtStudentsName.Text + "%') and students_enroll_no like('%" + mtxtEnrollno.Text + "%') and students_dept like('%" + mtxtstudentdep.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dgvstdsearch.DataSource = dt;
                sqlCon.Close();

                if (i == 0)
                {
                    MessageBox.Show("No Students Found");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtStudentid_KeyUp(object sender, KeyEventArgs e)
        {
            int i = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where  id like('%" + mtxtStudentid.Text + "%') and students_name like('%" + mtxtStudentsName.Text + "%') and students_enroll_no like('%" + mtxtEnrollno.Text + "%') and students_dept like('%" + mtxtstudentdep.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dgvstdsearch.DataSource = dt;
                sqlCon.Close();

                if (i == 0)
                {
                    MessageBox.Show("No Students Found");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtStudentsName_KeyUp(object sender, KeyEventArgs e)
        {
            int i = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where  id like('%" + mtxtStudentid.Text + "%') and students_name like('%" + mtxtStudentsName.Text + "%') and students_enroll_no like('%" + mtxtEnrollno.Text + "%') and students_dept like('%" + mtxtstudentdep.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dgvstdsearch.DataSource = dt;
                sqlCon.Close();

                if (i == 0)
                {
                    MessageBox.Show("No Students Found");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtEnrollno_KeyUp(object sender, KeyEventArgs e)
        {
            int i = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where  id like('%" + mtxtStudentid.Text + "%') and students_name like('%" + mtxtStudentsName.Text + "%') and students_enroll_no like('%" + mtxtEnrollno.Text + "%') and students_dept like('%" + mtxtstudentdep.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dgvstdsearch.DataSource = dt;
                sqlCon.Close();

                if (i == 0)
                {
                    MessageBox.Show("No Students Found");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtstudentdep_KeyUp(object sender, KeyEventArgs e)
        {
            int i = 0;
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where  id like('%" + mtxtStudentid.Text + "%') and students_name like('%" + mtxtStudentsName.Text + "%') and students_enroll_no like('%" + mtxtEnrollno.Text + "%') and students_dept like('%" + mtxtstudentdep.Text + "%')";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());

                dgvstdsearch.DataSource = dt;
                sqlCon.Close();

                if (i == 0)
                {
                    MessageBox.Show("No Students Found");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
