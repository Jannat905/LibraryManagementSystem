﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Update_Books :MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Update_Books()
        {
            InitializeComponent();
        }

        private void Update_Books_Load(object sender, EventArgs e)
        {
           //disp_books();
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvUpdatebooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            disp_books();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = Convert.ToInt32(dgvUpdatebooks.SelectedCells[0].Value.ToString());
            MessageBox.Show(i.ToString());

            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books where book_id="+i+"";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                foreach(DataRow dr in dt.Rows)
                {
                    mtxtBookname.Text = dr["book_name"].ToString();
                    mtxtBookauthor.Text = dr["book_author_name"].ToString();
                    mtxtBookpublication.Text = dr["book_publication_name"].ToString();
                    dtpupdatebookdate.Value= Convert.ToDateTime(dr["book_purchase_date"].ToString());
                    mtxtBookprice.Text = dr["book_price"].ToString();
                    mtxtBookquantity.Text = dr["book_quantity"].ToString();
                    mtxtBooktype.Text = dr["book_type"].ToString();

                }
                dgvUpdatebooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void mbtnupdatebook_Click(object sender, EventArgs e)
        {
            int i;
            i = Convert.ToInt32(dgvUpdatebooks.SelectedCells[0].Value.ToString());
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "update books  set book_name='"+mtxtBookname.Text+"' ,book_author_name='"+mtxtBookauthor.Text+"', book_publication_name='"+mtxtBookpublication.Text+"' ,book_purchase_date='"+dtpupdatebookdate.Value+"' ,book_price="+mtxtBookprice.Text+" ,book_quantity='"+mtxtBookquantity.Text+"' ,book_type='"+mtxtBooktype.Text+"' where book_id="+i+" ";
                sqcom.ExecuteNonQuery();
                sqlCon.Close();
                disp_books();

                mtxtBookname.Text = "";
                mtxtBookauthor.Text = "";
                mtxtBookpublication.Text = "";
                // mtxtBookdate.Text = "";
                mtxtBookprice.Text = "";
                mtxtBookquantity.Text = "";
                mtxtBooktype.Text = "";

                MessageBox.Show("Record Update");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void disp_books()
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from books";
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                dgvUpdatebooks.DataSource = dt;
                sqlCon.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
