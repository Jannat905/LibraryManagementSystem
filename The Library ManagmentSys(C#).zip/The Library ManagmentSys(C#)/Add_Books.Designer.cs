﻿namespace The_Library_ManagmentSys
{
    partial class Add_Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mtxtBooktype = new MetroFramework.Controls.MetroTextBox();
            this.mbtnSave = new MetroFramework.Controls.MetroButton();
            this.mtxtBookquantity = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookprice = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookpublication = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookauthor = new MetroFramework.Controls.MetroTextBox();
            this.mtxtBookname = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.dtpAddbook = new System.Windows.Forms.DateTimePicker();
            this.metroPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.dtpAddbook);
            this.metroPanel1.Controls.Add(this.mtxtBooktype);
            this.metroPanel1.Controls.Add(this.mbtnSave);
            this.metroPanel1.Controls.Add(this.mtxtBookquantity);
            this.metroPanel1.Controls.Add(this.mtxtBookprice);
            this.metroPanel1.Controls.Add(this.mtxtBookpublication);
            this.metroPanel1.Controls.Add(this.mtxtBookauthor);
            this.metroPanel1.Controls.Add(this.mtxtBookname);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(1, 78);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(799, 370);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mtxtBooktype
            // 
            this.mtxtBooktype.Location = new System.Drawing.Point(288, 278);
            this.mtxtBooktype.Name = "mtxtBooktype";
            this.mtxtBooktype.Size = new System.Drawing.Size(75, 23);
            this.mtxtBooktype.TabIndex = 16;
            // 
            // mbtnSave
            // 
            this.mbtnSave.Location = new System.Drawing.Point(297, 326);
            this.mbtnSave.Name = "mbtnSave";
            this.mbtnSave.Size = new System.Drawing.Size(75, 23);
            this.mbtnSave.TabIndex = 15;
            this.mbtnSave.Text = "Save";
            this.mbtnSave.Click += new System.EventHandler(this.mbtnSave_Click);
            // 
            // mtxtBookquantity
            // 
            this.mtxtBookquantity.Location = new System.Drawing.Point(288, 246);
            this.mtxtBookquantity.Name = "mtxtBookquantity";
            this.mtxtBookquantity.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookquantity.TabIndex = 14;
            // 
            // mtxtBookprice
            // 
            this.mtxtBookprice.Location = new System.Drawing.Point(288, 205);
            this.mtxtBookprice.Name = "mtxtBookprice";
            this.mtxtBookprice.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookprice.TabIndex = 13;
            // 
            // mtxtBookpublication
            // 
            this.mtxtBookpublication.Location = new System.Drawing.Point(288, 128);
            this.mtxtBookpublication.Name = "mtxtBookpublication";
            this.mtxtBookpublication.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookpublication.TabIndex = 11;
            // 
            // mtxtBookauthor
            // 
            this.mtxtBookauthor.Location = new System.Drawing.Point(288, 94);
            this.mtxtBookauthor.Name = "mtxtBookauthor";
            this.mtxtBookauthor.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookauthor.TabIndex = 10;
            // 
            // mtxtBookname
            // 
            this.mtxtBookname.Location = new System.Drawing.Point(288, 52);
            this.mtxtBookname.Name = "mtxtBookname";
            this.mtxtBookname.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookname.TabIndex = 9;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(53, 283);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(80, 19);
            this.metroLabel7.TabIndex = 8;
            this.metroLabel7.Text = "Book Type";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.Location = new System.Drawing.Point(53, 246);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(105, 19);
            this.metroLabel6.TabIndex = 7;
            this.metroLabel6.Text = "Book Quantity";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(53, 205);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(82, 19);
            this.metroLabel5.TabIndex = 6;
            this.metroLabel5.Text = "Book Price";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(53, 166);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(40, 19);
            this.metroLabel4.TabIndex = 5;
            this.metroLabel4.Text = "Date";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(53, 128);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(123, 19);
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Book Publication";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(53, 94);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(138, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Book Author Name";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(55, 56);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(88, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Book Name";
            // 
            // dtpAddbook
            // 
            this.dtpAddbook.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpAddbook.Location = new System.Drawing.Point(288, 164);
            this.dtpAddbook.Name = "dtpAddbook";
            this.dtpAddbook.Size = new System.Drawing.Size(100, 20);
            this.dtpAddbook.TabIndex = 17;
            // 
            // Add_Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Add_Books";
            this.Text = "Add_Books";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Add_Books_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnSave;
        private MetroFramework.Controls.MetroTextBox mtxtBookquantity;
        private MetroFramework.Controls.MetroTextBox mtxtBookprice;
        private MetroFramework.Controls.MetroTextBox mtxtBookpublication;
        private MetroFramework.Controls.MetroTextBox mtxtBookauthor;
        private MetroFramework.Controls.MetroTextBox mtxtBookname;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox mtxtBooktype;
        private System.Windows.Forms.DateTimePicker dtpAddbook;
    }
}