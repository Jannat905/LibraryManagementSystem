﻿namespace The_Library_ManagmentSys
{
    partial class Books_Record
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvbookrecord1 = new System.Windows.Forms.DataGridView();
            this.dgvbookrecord2 = new System.Windows.Forms.DataGridView();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.mtxtbookname = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.mtxtemail = new MetroFramework.Controls.MetroTextBox();
            this.mtxtcontent = new MetroFramework.Controls.MetroTextBox();
            this.mbtnsend = new MetroFramework.Controls.MetroButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbookrecord1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbookrecord2)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvbookrecord1
            // 
            this.dgvbookrecord1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvbookrecord1.Location = new System.Drawing.Point(268, 63);
            this.dgvbookrecord1.Name = "dgvbookrecord1";
            this.dgvbookrecord1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvbookrecord1.Size = new System.Drawing.Size(509, 184);
            this.dgvbookrecord1.TabIndex = 0;
            this.dgvbookrecord1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvbookrecord1_CellClick);
            // 
            // dgvbookrecord2
            // 
            this.dgvbookrecord2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvbookrecord2.Location = new System.Drawing.Point(268, 253);
            this.dgvbookrecord2.Name = "dgvbookrecord2";
            this.dgvbookrecord2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvbookrecord2.Size = new System.Drawing.Size(509, 169);
            this.dgvbookrecord2.TabIndex = 1;
            this.dgvbookrecord2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvbookrecord2_CellClick);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(23, 63);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(88, 19);
            this.metroLabel2.TabIndex = 3;
            this.metroLabel2.Text = "Book Name";
            // 
            // mtxtbookname
            // 
            this.mtxtbookname.Location = new System.Drawing.Point(24, 100);
            this.mtxtbookname.Name = "mtxtbookname";
            this.mtxtbookname.Size = new System.Drawing.Size(87, 23);
            this.mtxtbookname.TabIndex = 4;
            this.mtxtbookname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtbookname_KeyUp);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(13, 179);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(45, 19);
            this.metroLabel1.TabIndex = 5;
            this.metroLabel1.Text = "Email";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(13, 228);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(61, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Content";
            // 
            // mtxtemail
            // 
            this.mtxtemail.Location = new System.Drawing.Point(94, 179);
            this.mtxtemail.Name = "mtxtemail";
            this.mtxtemail.Size = new System.Drawing.Size(75, 23);
            this.mtxtemail.TabIndex = 7;
            // 
            // mtxtcontent
            // 
            this.mtxtcontent.Location = new System.Drawing.Point(94, 228);
            this.mtxtcontent.Name = "mtxtcontent";
            this.mtxtcontent.Size = new System.Drawing.Size(75, 23);
            this.mtxtcontent.TabIndex = 8;
            // 
            // mbtnsend
            // 
            this.mbtnsend.Location = new System.Drawing.Point(82, 319);
            this.mbtnsend.Name = "mbtnsend";
            this.mbtnsend.Size = new System.Drawing.Size(75, 23);
            this.mbtnsend.TabIndex = 9;
            this.mbtnsend.Text = "Send";
            this.mbtnsend.Click += new System.EventHandler(this.mbtnsend_Click);
            // 
            // Books_Record
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mbtnsend);
            this.Controls.Add(this.mtxtcontent);
            this.Controls.Add(this.mtxtemail);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.mtxtbookname);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.dgvbookrecord2);
            this.Controls.Add(this.dgvbookrecord1);
            this.Name = "Books_Record";
            this.Text = "Books_Record";
            this.Load += new System.EventHandler(this.Books_Record_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvbookrecord1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvbookrecord2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvbookrecord1;
        private System.Windows.Forms.DataGridView dgvbookrecord2;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox mtxtbookname;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox mtxtemail;
        private MetroFramework.Controls.MetroTextBox mtxtcontent;
        private MetroFramework.Controls.MetroButton mbtnsend;
    }
}