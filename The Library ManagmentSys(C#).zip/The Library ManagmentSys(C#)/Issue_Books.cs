﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace The_Library_ManagmentSys
{
    public partial class Issue_Books :MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Issue_Books()
        {
            InitializeComponent();
        }

        private void Issue_Books_Load(object sender, EventArgs e)
        {
            if(sqlCon.State==ConnectionState.Open)
            {
                sqlCon.Close();
            }
            sqlCon.Open();
        }

        private void mbtnStdsearch_Click(object sender, EventArgs e)
        {
            //try
            
            int i = 0;
            try
            {



                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "select * from students_info where students_enroll_no='" + mtxtenrollno.Text + "'";
                sqcom.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(sqcom);
                da.Fill(dt);
                i = Convert.ToInt32(dt.Rows.Count.ToString());
                if (i == 0)
                {
                    MessageBox.Show("This Enrollment NO NOt Found");
                }
                else
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        //mtxtstdname.Text = dr[""].ToString();
                        mtxtstdname.Text = dr["students_name"].ToString();
                        mtxtstdenroll.Text = dr["students_enroll_no"].ToString();
                        mtxtStudentdept.Text = dr["students_dept"].ToString();
                        mtxtxStudentsem.Text = dr["students_sem"].ToString();
                        mtxtStudentcontact.Text = dr["students_contact"].ToString();
                        mtxtStudentemail.Text = dr["students_email"].ToString();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mtxtBookname_KeyUp(object sender, KeyEventArgs e)
        {
            int count = 0;
            try
            {



                if (e.KeyCode != Keys.Enter)
                {
                    listBox1.Items.Clear();

                    SqlCommand sqcom = sqlCon.CreateCommand();
                    sqcom.CommandType = CommandType.Text;
                    sqcom.CommandText = "select * from books where book_name like('%" + mtxtBookname.Text + "%')";
                    sqcom.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(sqcom);
                    da.Fill(dt);
                    count = Convert.ToInt32(dt.Rows.Count.ToString());

                    if (count > 0)
                    {
                        listBox1.Visible = true;
                        foreach (DataRow dr in dt.Rows)
                        {
                            listBox1.Items.Add(dr["book_name"].ToString());
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void mtxtBookname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                listBox1.Focus();
                listBox1.SelectedIndex = 0;
            }
        }

        private void listBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                mtxtBookname.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            }
        }

        private void listBox1_MouseClick(object sender, MouseEventArgs e)
        {
            mtxtBookname.Text = listBox1.SelectedItem.ToString();
            listBox1.Visible = false;
        }

        private void mbtnissuebook_Click(object sender, EventArgs e)
        {


            int book_quan=0;
            try
            {
                //int book_quan = 0;



                SqlCommand sqcom2 = sqlCon.CreateCommand();
                sqcom2.CommandType = CommandType.Text;
                sqcom2.CommandText = " select * from books where book_name='" + mtxtBookname.Text + "'";
                sqcom2.ExecuteNonQuery();
                DataTable dt2 = new DataTable();
                SqlDataAdapter da2 = new SqlDataAdapter(sqcom2);
                da2.Fill(dt2);
                // MessageBox.Show("Books issued Successfully");

                foreach (DataRow dr2 in dt2.Rows)
                {
                    book_quan = Convert.ToInt32(dr2["available_quantity"].ToString());
                }


                if (book_quan > 0)
                {

                    SqlCommand sqcom = sqlCon.CreateCommand();
                    sqcom.CommandType = CommandType.Text;
                    sqcom.CommandText = "insert into issue_books(student_name,students_enroll_no,students_dept,students_sem,students_contact,students_email,book_name,books_issue_date,books_return_date) values('" + mtxtstdname.Text + "','" + mtxtstdenroll.Text + "','" + mtxtStudentdept.Text + "','" + mtxtxStudentsem.Text + "','" + mtxtStudentcontact.Text + "','" + mtxtStudentemail.Text + "','" + mtxtBookname.Text + "','" + dtpissuebook.Value + "','')";
                    sqcom.ExecuteNonQuery();
                    //MessageBox.Show("Books issued Successfully");



                    SqlCommand sqcom1 = sqlCon.CreateCommand();
                    sqcom1.CommandType = CommandType.Text;
                    sqcom1.CommandText = "update books set available_quantity = available_quantity - 1 where book_name= '" + mtxtBookname.Text + "'";
                    //sqcom1.CommandText = v;
                    sqcom1.ExecuteNonQuery();
                    MessageBox.Show("Books issued Successfully");
                }
                else
                {
                    MessageBox.Show("Books not available");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void metroLabel5_Click(object sender, EventArgs e)
        {

        }

        private void dtpissuebook_ValueChanged(object sender, EventArgs e)
        {

        }

        private void mtxtBookname_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel6_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void mtxtStudentemail_Click(object sender, EventArgs e)
        {

        }

        private void mtxtStudentcontact_Click(object sender, EventArgs e)
        {

        }
    }
}
