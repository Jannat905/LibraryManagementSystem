﻿namespace The_Library_ManagmentSys
{
    partial class Issue_Books
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.mbtnStdsearch = new MetroFramework.Controls.MetroButton();
            this.mtxtenrollno = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.mtxtStudentemail = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentcontact = new MetroFramework.Controls.MetroTextBox();
            this.mtxtxStudentsem = new MetroFramework.Controls.MetroTextBox();
            this.mtxtStudentdept = new MetroFramework.Controls.MetroTextBox();
            this.mtxtstdname = new MetroFramework.Controls.MetroTextBox();
            this.mtxtstdenroll = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.dgvissuebooks = new System.Windows.Forms.DataGridView();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.mtxtBookname = new MetroFramework.Controls.MetroTextBox();
            this.dtpissuebook = new System.Windows.Forms.DateTimePicker();
            this.mbtnissuebook = new MetroFramework.Controls.MetroButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvissuebooks)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.Aqua;
            this.metroPanel1.Controls.Add(this.listBox1);
            this.metroPanel1.Controls.Add(this.mbtnissuebook);
            this.metroPanel1.Controls.Add(this.dtpissuebook);
            this.metroPanel1.Controls.Add(this.mtxtBookname);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.Controls.Add(this.dgvissuebooks);
            this.metroPanel1.Controls.Add(this.metroLabel6);
            this.metroPanel1.Controls.Add(this.metroLabel5);
            this.metroPanel1.Controls.Add(this.metroLabel4);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.metroLabel7);
            this.metroPanel1.Controls.Add(this.mtxtStudentemail);
            this.metroPanel1.Controls.Add(this.mtxtStudentcontact);
            this.metroPanel1.Controls.Add(this.mtxtxStudentsem);
            this.metroPanel1.Controls.Add(this.mtxtStudentdept);
            this.metroPanel1.Controls.Add(this.mtxtstdname);
            this.metroPanel1.Controls.Add(this.mtxtstdenroll);
            this.metroPanel1.Controls.Add(this.metroLabel8);
            this.metroPanel1.Controls.Add(this.mbtnStdsearch);
            this.metroPanel1.Controls.Add(this.mtxtenrollno);
            this.metroPanel1.CustomBackground = true;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(45, 79);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(653, 430);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // mbtnStdsearch
            // 
            this.mbtnStdsearch.Location = new System.Drawing.Point(184, 31);
            this.mbtnStdsearch.Name = "mbtnStdsearch";
            this.mbtnStdsearch.Size = new System.Drawing.Size(93, 23);
            this.mbtnStdsearch.TabIndex = 6;
            this.mbtnStdsearch.Text = "Student Search";
            this.mbtnStdsearch.Click += new System.EventHandler(this.mbtnStdsearch_Click);
            // 
            // mtxtenrollno
            // 
            this.mtxtenrollno.Location = new System.Drawing.Point(28, 31);
            this.mtxtenrollno.Name = "mtxtenrollno";
            this.mtxtenrollno.Size = new System.Drawing.Size(122, 23);
            this.mtxtenrollno.TabIndex = 4;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.ForeColor = System.Drawing.Color.Black;
            this.metroLabel6.Location = new System.Drawing.Point(338, 40);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(115, 19);
            this.metroLabel6.TabIndex = 35;
            this.metroLabel6.Text = "Student Contact";
            this.metroLabel6.Click += new System.EventHandler(this.metroLabel6_Click);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.BackColor = System.Drawing.Color.DarkSlateGray;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(338, 80);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(100, 19);
            this.metroLabel5.TabIndex = 34;
            this.metroLabel5.Text = "Student Email";
            this.metroLabel5.Click += new System.EventHandler(this.metroLabel5_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.BackColor = System.Drawing.Color.DarkSlateGray;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(28, 206);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(126, 19);
            this.metroLabel4.TabIndex = 33;
            this.metroLabel4.Text = "Student Semester";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(24, 160);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(144, 19);
            this.metroLabel3.TabIndex = 32;
            this.metroLabel3.Text = "Student Department";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(24, 120);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(126, 19);
            this.metroLabel7.TabIndex = 31;
            this.metroLabel7.Text = "Student Enroll No";
            // 
            // mtxtStudentemail
            // 
            this.mtxtStudentemail.Location = new System.Drawing.Point(529, 80);
            this.mtxtStudentemail.Name = "mtxtStudentemail";
            this.mtxtStudentemail.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentemail.TabIndex = 30;
            this.mtxtStudentemail.Click += new System.EventHandler(this.mtxtStudentemail_Click);
            // 
            // mtxtStudentcontact
            // 
            this.mtxtStudentcontact.Location = new System.Drawing.Point(529, 40);
            this.mtxtStudentcontact.Name = "mtxtStudentcontact";
            this.mtxtStudentcontact.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentcontact.TabIndex = 29;
            this.mtxtStudentcontact.Click += new System.EventHandler(this.mtxtStudentcontact_Click);
            // 
            // mtxtxStudentsem
            // 
            this.mtxtxStudentsem.Location = new System.Drawing.Point(202, 206);
            this.mtxtxStudentsem.Name = "mtxtxStudentsem";
            this.mtxtxStudentsem.Size = new System.Drawing.Size(75, 23);
            this.mtxtxStudentsem.TabIndex = 28;
            // 
            // mtxtStudentdept
            // 
            this.mtxtStudentdept.Location = new System.Drawing.Point(202, 160);
            this.mtxtStudentdept.Name = "mtxtStudentdept";
            this.mtxtStudentdept.Size = new System.Drawing.Size(75, 23);
            this.mtxtStudentdept.TabIndex = 27;
            // 
            // mtxtstdname
            // 
            this.mtxtstdname.Location = new System.Drawing.Point(202, 80);
            this.mtxtstdname.Name = "mtxtstdname";
            this.mtxtstdname.Size = new System.Drawing.Size(75, 23);
            this.mtxtstdname.TabIndex = 26;
            // 
            // mtxtstdenroll
            // 
            this.mtxtstdenroll.Location = new System.Drawing.Point(202, 120);
            this.mtxtstdenroll.Name = "mtxtstdenroll";
            this.mtxtstdenroll.Size = new System.Drawing.Size(75, 23);
            this.mtxtstdenroll.TabIndex = 25;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel8.Location = new System.Drawing.Point(24, 80);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(104, 19);
            this.metroLabel8.TabIndex = 24;
            this.metroLabel8.Text = "Student Name";
            // 
            // dgvissuebooks
            // 
            this.dgvissuebooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvissuebooks.Location = new System.Drawing.Point(3, 272);
            this.dgvissuebooks.Name = "dgvissuebooks";
            this.dgvissuebooks.Size = new System.Drawing.Size(647, 155);
            this.dgvissuebooks.TabIndex = 36;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(344, 120);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(94, 19);
            this.metroLabel1.TabIndex = 37;
            this.metroLabel1.Text = "Books Name";
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(344, 160);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(76, 19);
            this.metroLabel2.TabIndex = 38;
            this.metroLabel2.Text = "Issue Date";
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel2_Click);
            // 
            // mtxtBookname
            // 
            this.mtxtBookname.Location = new System.Drawing.Point(529, 120);
            this.mtxtBookname.Name = "mtxtBookname";
            this.mtxtBookname.Size = new System.Drawing.Size(75, 23);
            this.mtxtBookname.TabIndex = 39;
            this.mtxtBookname.Click += new System.EventHandler(this.mtxtBookname_Click);
            this.mtxtBookname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mtxtBookname_KeyDown);
            this.mtxtBookname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mtxtBookname_KeyUp);
            // 
            // dtpissuebook
            // 
            this.dtpissuebook.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpissuebook.Location = new System.Drawing.Point(524, 160);
            this.dtpissuebook.Name = "dtpissuebook";
            this.dtpissuebook.Size = new System.Drawing.Size(80, 20);
            this.dtpissuebook.TabIndex = 40;
            this.dtpissuebook.ValueChanged += new System.EventHandler(this.dtpissuebook_ValueChanged);
            // 
            // mbtnissuebook
            // 
            this.mbtnissuebook.Location = new System.Drawing.Point(305, 227);
            this.mbtnissuebook.Name = "mbtnissuebook";
            this.mbtnissuebook.Size = new System.Drawing.Size(93, 23);
            this.mbtnissuebook.TabIndex = 41;
            this.mbtnissuebook.Text = "Issue Books";
            this.mbtnissuebook.Click += new System.EventHandler(this.mbtnissuebook_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(529, 140);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(75, 43);
            this.listBox1.TabIndex = 42;
            this.listBox1.Visible = false;
            this.listBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseClick);
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listBox1_KeyDown);
            // 
            // Issue_Books
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 532);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Issue_Books";
            this.Text = "Issue_Books";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Issue_Books_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvissuebooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroButton mbtnStdsearch;
        private MetroFramework.Controls.MetroTextBox mtxtenrollno;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTextBox mtxtStudentemail;
        private MetroFramework.Controls.MetroTextBox mtxtStudentcontact;
        private MetroFramework.Controls.MetroTextBox mtxtxStudentsem;
        private MetroFramework.Controls.MetroTextBox mtxtStudentdept;
        private MetroFramework.Controls.MetroTextBox mtxtstdname;
        private MetroFramework.Controls.MetroTextBox mtxtstdenroll;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.DateTimePicker dtpissuebook;
        private MetroFramework.Controls.MetroTextBox mtxtBookname;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.DataGridView dgvissuebooks;
        private MetroFramework.Controls.MetroButton mbtnissuebook;
        private System.Windows.Forms.ListBox listBox1;
    }
}