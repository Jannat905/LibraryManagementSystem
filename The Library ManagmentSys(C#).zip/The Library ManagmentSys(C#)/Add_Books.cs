﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace The_Library_ManagmentSys
{
    public partial class Add_Books : MetroFramework.Forms.MetroForm
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=MUSHFIKA\JANNAT;Initial Catalog=LibraryManagmentSys;User ID=sa;Password=jannat02");
        public Add_Books()
        {
            InitializeComponent();
        }

        private void Add_Books_Load(object sender, EventArgs e)
        {

        }

        private void mbtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                SqlCommand sqcom = sqlCon.CreateCommand();
                sqcom.CommandType = CommandType.Text;
                sqcom.CommandText = "insert into books(book_name,book_author_name,book_publication_name,book_purchase_date,book_price,book_quantity,book_type,available_quantity) values ('" + mtxtBookname.Text + "','" + mtxtBookauthor.Text + "','" + mtxtBookpublication.Text + "','" + dtpAddbook.Value + "'," + mtxtBookprice.Text + "," + mtxtBookquantity.Text + ",'" + mtxtBooktype.Text +"',"+ mtxtBookquantity.Text + ")";
               // sqcom.CommandText = "insert into books values(''" + mtxtBookname.Text + "','" + mtxtBookauthor.Text + "','" + mtxtBookpublication.Text + "','" + mtxtBookdate.Text + "'," + mtxtBookprice.Text + "," + mtxtBookquantity.Text + ",'" + mtxtBooktype.Text + "')";
                sqcom.ExecuteNonQuery();
                sqlCon.Close();

                mtxtBookname.Text = "";
                mtxtBookauthor.Text = "";
                mtxtBookpublication.Text = "";
               // mtxtBookdate.Text = "";
                mtxtBookprice.Text = "";
                mtxtBookquantity.Text = "";
                mtxtBooktype.Text = "";

                MessageBox.Show("Book Added");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }
    }
}
